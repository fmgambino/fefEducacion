/* ================================
   FEF Educación - Sitio en Construcción
   Archivo: script.js
   ================================ */

/*
  ✅ MODIFICAR FECHA Y HORA DE INAUGURACIÓN AQUÍ

  Formato recomendado:
  YYYY-MM-DDTHH:mm:ss-03:00

  -03:00 representa la hora de Argentina.
  Ejemplo:
  const LAUNCH_DATE_ARG = "2026-06-23T00:00:00-03:00";

  Esta fecha fue calculada como 20 días hábiles desde el 26/05/2026.
*/
const LAUNCH_DATE_ARG = "2026-06-23T00:00:00-03:00";

// Elementos del contador
const daysEl = document.querySelector("#days");
const hoursEl = document.querySelector("#hours");
const minutesEl = document.querySelector("#minutes");
const secondsEl = document.querySelector("#seconds");
const targetDateLabel = document.querySelector("#targetDateLabel");
const locationLabel = document.querySelector("#locationLabel");
const themeToggle = document.querySelector("#themeToggle");
const form = document.querySelector(".notify-form");
const formMessage = document.querySelector("#formMessage");

const targetDate = new Date(LAUNCH_DATE_ARG);

const formatterArgentina = new Intl.DateTimeFormat("es-AR", {
  dateStyle: "full",
  timeStyle: "short",
  timeZone: "America/Argentina/Buenos_Aires"
});

targetDateLabel.textContent = formatterArgentina.format(targetDate);

function pad(value) {
  return String(value).padStart(2, "0");
}

function updateCountdown() {
  const now = new Date();
  const distance = targetDate.getTime() - now.getTime();

  if (distance <= 0) {
    document.querySelector("#countdown").innerHTML = `
      <div class="time-box" style="grid-column: 1 / -1;">
        <strong>¡Ya estamos online!</strong>
        <small>FEF Educación</small>
      </div>
    `;
    return;
  }

  const totalSeconds = Math.floor(distance / 1000);
  const days = Math.floor(totalSeconds / 86400);
  const hours = Math.floor((totalSeconds % 86400) / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;

  daysEl.textContent = pad(days);
  hoursEl.textContent = pad(hours);
  minutesEl.textContent = pad(minutes);
  secondsEl.textContent = pad(seconds);
}

updateCountdown();
setInterval(updateCountdown, 1000);

// Detectar país por configuración del navegador.
// Nota: para país exacto por IP se necesita un servicio externo/API.
// Este método respeta más la privacidad y no requiere claves.
function detectCountryFromLocale() {
  const locale = navigator.language || navigator.userLanguage || "es-AR";
  const region = locale.split("-")[1];

  const regionNames = new Intl.DisplayNames(["es"], { type: "region" });

  if (region) {
    locationLabel.textContent = `Ingresando desde ${regionNames.of(region)} · Lanzamiento 00:00 ARG`;
  } else {
    locationLabel.textContent = "Ubicación aproximada no disponible · Lanzamiento 00:00 ARG";
  }
}

detectCountryFromLocale();

// Tema oscuro/claro
const savedTheme = localStorage.getItem("fef-theme");
const prefersLight = window.matchMedia("(prefers-color-scheme: light)").matches;
const initialTheme = savedTheme || (prefersLight ? "light" : "dark");

document.documentElement.setAttribute("data-theme", initialTheme);
updateThemeButton(initialTheme);

themeToggle.addEventListener("click", () => {
  const current = document.documentElement.getAttribute("data-theme");
  const next = current === "dark" ? "light" : "dark";
  document.documentElement.setAttribute("data-theme", next);
  localStorage.setItem("fef-theme", next);
  updateThemeButton(next);
});

function updateThemeButton(theme) {
  const icon = themeToggle.querySelector(".theme-icon");
  icon.textContent = theme === "dark" ? "☀️" : "🌙";
}

// Formulario demo
form.addEventListener("submit", (event) => {
  event.preventDefault();

  const email = document.querySelector("#email").value.trim();

  if (!email) {
    formMessage.textContent = "Ingresá tu email para recibir novedades.";
    return;
  }

  formMessage.textContent = "¡Gracias! Te avisaremos cuando FEF Educación esté lista.";
  form.reset();
});

// Año footer
document.querySelector("#year").textContent = new Date().getFullYear();

// AOS
AOS.init({
  duration: 900,
  once: true,
  easing: "ease-out-cubic"
});

// Particles.js
particlesJS("particles-js", {
  particles: {
    number: {
      value: 70,
      density: {
        enable: true,
        value_area: 900
      }
    },
    color: {
      value: ["#7c3cff", "#00e5ff", "#00ff95"]
    },
    shape: {
      type: "circle"
    },
    opacity: {
      value: 0.35,
      random: true
    },
    size: {
      value: 3,
      random: true
    },
    line_linked: {
      enable: true,
      distance: 145,
      color: "#00e5ff",
      opacity: 0.18,
      width: 1
    },
    move: {
      enable: true,
      speed: 1.2,
      direction: "none",
      random: true,
      straight: false,
      out_mode: "out",
      bounce: false
    }
  },
  interactivity: {
    detect_on: "canvas",
    events: {
      onhover: {
        enable: true,
        mode: "grab"
      },
      onclick: {
        enable: true,
        mode: "push"
      },
      resize: true
    },
    modes: {
      grab: {
        distance: 170,
        line_linked: {
          opacity: 0.35
        }
      },
      push: {
        particles_nb: 4
      }
    }
  },
  retina_detect: true
});

// Animaciones GSAP
gsap.from(".brand", {
  y: -18,
  opacity: 0,
  duration: 0.9,
  ease: "power3.out"
});

gsap.from(".theme-toggle", {
  y: -18,
  opacity: 0,
  duration: 0.9,
  delay: 0.15,
  ease: "power3.out"
});

gsap.to(".orb-one", {
  x: 35,
  y: -25,
  duration: 5,
  repeat: -1,
  yoyo: true,
  ease: "sine.inOut"
});

gsap.to(".orb-two", {
  x: -30,
  y: 35,
  duration: 6,
  repeat: -1,
  yoyo: true,
  ease: "sine.inOut"
});
