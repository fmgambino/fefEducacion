FEF Educación - Landing Page Sitio en Construcción

Archivos:
- index.html
- styles.css
- script.js

Cómo probar:
1. Descomprimir el ZIP.
2. Abrir index.html en el navegador.
3. Para modificar fecha y hora, abrir script.js y cambiar:
   const LAUNCH_DATE_ARG = "2026-06-23T00:00:00-03:00";

Formato:
YYYY-MM-DDTHH:mm:ss-03:00

Nota:
La detección de país usa el idioma/región del navegador. Para país exacto por IP se recomienda integrar una API externa.
